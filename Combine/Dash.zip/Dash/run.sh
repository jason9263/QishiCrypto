#!/bin/bash

source /home/runmin/Documents/Crypto_QR/dash/bin/activate
python app.py
